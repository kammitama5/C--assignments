#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>


using namespace std;

int main()
{


	string planetChosen;



	//set precision two digits after . (five spaces)

	// programme starts
	cout << "Welcome to INTERPLANETARY TRAVEL PROGRAM!\n";
	cout << "This program enables you to find out your travel time to the planet\n";
	cout << "you want to travel to as well as your weight on that planet.\n";
	cout << "Please enjoy the program and find the perfect planet for you!\n";
	cout << "\n";
	cout << "\n";

	//user chooses a planet
	cout << "INTERPLANETARY TRAVEL MENU\n";
	cout << "--------------------------\n";
	cout << "a) Mercury\n";
	cout << "b) Venus\n";
	cout << "c) Earth\n";
	cout << "d) Mars\n";
	cout << "e) Jupiter\n";
	cout << "f) Saturn\n";
	cout << "g) Uranus\n";
	cout << "h) Neptune\n";
	cout << "q) quit\n";
	cout << "\n";

	//Ask the user to select a planet
	cout << "Select a planet to travel to or q to quit the program: ";
	char planetChoice;
	cin >> planetChoice;
	cout << "\n";

	

	//if planet char chosen, planetString is planet, weight is, time (in days, hours, years) is


	if (planetChoice == 'q'){
		cout << "You have chosen to quit the program. Thank you for using the program!\n";
		return 0;
	}
	
	else if(planetChoice == 'a' || 'b' || 'c' || 'd' || 'e' || 'f' || 'g' || 'h'){
		{if (planetChoice == 'a'){
			planetChosen = "Mercury";
		}
		else if (planetChoice == 'b'){
			planetChosen = "Venus";
		}
		else if (planetChoice == 'c'){
			planetChosen = "Earth";;
		}
		else if (planetChoice == 'd'){
			planetChosen = "Mars";
		}
		else if (planetChoice == 'e'){
			planetChosen = "Jupiter";
		}
		else if (planetChoice == 'f'){
			planetChosen = "Saturn";
		}
		else if (planetChoice == 'g'){
			planetChosen = "Uranus";
		}
		else if (planetChoice == 'h'){
			planetChosen = "Neptune";
		}
		else {
			cout << "You have entered an invalid selection.\n";
		}
		}
	}
	else {
		cout << "You have entered an invalid selection.\n";
		
	}

	


	//if planet chosen equals blah, cout specific weight, etc

	if (planetChosen == "Mercury"){
		
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;
	

		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;

		double yourWeightOnPlanet = (yourWeight * 0.27);
		double yourHoursonPlanet = ceil((57000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ceil((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);

		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Mercury:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Mercury:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";

	}
	if (planetChosen == "Venus"){

		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		cout << "\n";


		
		double yourWeightOnPlanet = (yourWeight * 0.86);
		double yourHoursonPlanet = ceil((26000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ceil((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Venus:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Venus:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "   In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Earth"){
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): ";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;
		cout << "\n";

		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: ";
		cin >> yourSpeed;

		
		cout << fixed << setprecision(2);
		double yourWeightOnPlanet = (yourWeight * 1.00);
		double yourHoursonPlanet = 0;
		double yourTimeinDaysOnPlanet = 0;
		double yourTimeinYearsOnPlanet = 0.00;
		cout << "\n";
		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Earth:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Earth:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Mars"){

		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		

		
		double yourWeightOnPlanet = (yourWeight * 0.37);
		double yourHoursonPlanet = ((48000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Mars:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Mars:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Jupiter"){
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		cout << "\n";


	
		double yourWeightOnPlanet = (yourWeight * 2.64);
		double yourHoursonPlanet = ((390000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Jupiter:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Jupiter:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Saturn"){
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		cout << "\n";


		
		double yourWeightOnPlanet = (yourWeight * 1.17);
		double yourHoursonPlanet = ((793000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		cout << "\n";
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Saturn:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Saturn:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Uranus"){
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		cout << "\n";

		
		double yourWeightOnPlanet = (yourWeight * 0.92);
		double yourHoursonPlanet = ((1689000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Uranus:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Uranus:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	if (planetChosen == "Neptune"){
		//Ask the user to enter their weight (politely)
		cout << "Please enter your weight (in lbs): \n";
		double yourWeight;
		cout << fixed << setprecision(2);
		cin >> yourWeight;


		//Ask the user to enter their preferred speed
		double yourSpeed;
		cout << fixed << setprecision(2);
		cout << "Please enter the speed (in mile per hour) that you would like to travel at: \n";
		cin >> yourSpeed;
		cout << "\n";


		
		double yourWeightOnPlanet = (yourWeight * 1.44);
		double yourHoursonPlanet = ((2700000000 / yourSpeed));
		double yourTimeinDaysOnPlanet = ((yourHoursonPlanet / 24.0));
		double yourTimeinYearsOnPlanet = (yourTimeinDaysOnPlanet / 365.0);
		
		cout << "INTERPLANETARY TRAVEL:  Earth to " << planetChosen << "\n";
		cout << "--------------------------------------------------\n";
		cout << "Your weight on Neptune:      " << yourWeightOnPlanet << " lbs\n";
		cout << "\n";
		cout << "Your travel time to Neptune:\n";
		cout << fixed << setprecision(0);
		cout << "    In Hours: " << yourHoursonPlanet << " hours\n";
		cout << fixed << setprecision(0);
		cout << "    In Days : " << yourTimeinDaysOnPlanet << " days\n";
		cout << fixed << setprecision(2);
		cout << "    In Years : " << yourTimeinYearsOnPlanet << " years\n";
		cout << "\n";
	}
	
	return 0;
}